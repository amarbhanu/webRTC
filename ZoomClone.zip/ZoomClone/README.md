## 🔵 Zoom Clone

- Real time messaging chat and video/audio communication using Socket.io, Peer.js, Nodejs, Express, and EJS.
- Version 2.0

## URL / Live version
To check out the live demo of this app:
- [azoom.herokuapp.com](https://azoom.herokuapp.com)

![Zoom Clone Room](https://github.com/louiejancevski/ZoomClone/blob/master/public/img/zoom.png)
